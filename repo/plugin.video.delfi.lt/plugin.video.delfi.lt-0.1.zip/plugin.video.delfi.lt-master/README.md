# plugin.video.delfi.lt

„[Kodi](http://kodi.tv/)“ grotuvo įskiepis skirtas žiūrėti tiesioginėms transliacijoms ir video įrašams iš http://www.delfi.lt/video/ puslapio. 

## Instaliavimas
1. Parsisiųskite [įskiepio failą](https://github.com/Vytax/plugin.video.delfi.lt/archive/master.zip) ir išsaugokite jį kietąjame diske.
2. Paleiskite „Kodi“ grotuvą. Atverkite programos nustatymus „System -> Settings“ ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.delfi.lt/master/resources/howto/howto1.jpg)
3. Atverkite įskiepių (Add-ons) skiltį: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.delfi.lt/master/resources/howto/howto2.jpg)
4. Pasirinkite „Install from zip file“: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.delfi.lt/master/resources/howto/howto3.jpg)
5. Nurodykite pirmojo etapo metu išsaugotą failą: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.delfi.lt/master/resources/howto/howto4.jpg)
6. Jau dabar Delfi TV įskiepis turėtų būti sėkmingai instaliuotas. Užverkite programos nustatymus. Naują įskiepį nuo šiol turėtumėte rasti atvertę „Videos -> Add-ons“ dalį: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.delfi.lt/master/resources/howto/howto5.jpg)
