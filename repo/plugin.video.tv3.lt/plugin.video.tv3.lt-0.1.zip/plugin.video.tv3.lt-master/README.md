# plugin.video.tv3.lt

„[Kodi](http://kodi.tv/)“ grotuvo įskiepis skirtas žiūrėti tiesioginėms transliacijoms ir video įrašams iš http://play.tv3.lt/ video puslapio. 

## Instaliavimas
1. Parsisiųskite [įskiepio failą](https://github.com/Vytax/plugin.video.tv3.lt/archive/master.zip) ir išsaugokite jį kietąjame diske.
2. Paleiskite „Kodi“ grotuvą. Atverkite programos nustatymus „System -> Settings“ ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.tv3.lt/master/resources/howto1.jpg)
3. Atverkite įskiepių (Add-ons) skiltį: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.tv3.lt/master/resources/howto2.jpg)
4. Pasirinkite „Install from zip file“: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.tv3.lt/master/resources/howto3.jpg)
5. Nurodykite pirmojo etapo metu išsaugotą failą: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.tv3.lt/master/resources/howto4.jpg)
6. Jau dabar TV3 TV įskiepis turėtų būti sėkmingai instaliuotas. Užverkite programos nustatymus. Naują įskiepį nuo šiol turėtumėte rasti atvertę „Videos -> Add-ons“ dalį: ![alt tag](https://raw.githubusercontent.com/Vytax/plugin.video.tv3.lt/master/resources/howto5.jpg)
