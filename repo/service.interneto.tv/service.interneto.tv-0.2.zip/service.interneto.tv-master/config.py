#!/usr/bin/python
# -*- coding: utf-8 -*-

PORT = 9080
HOST = '127.0.0.1'
CACHE_DIR = 'cache/'
EPG_FILE = CACHE_DIR + 'epg_%s.xml' 

EMAIL = 'user@email.com'
PASSWORD = 'qwerty'
